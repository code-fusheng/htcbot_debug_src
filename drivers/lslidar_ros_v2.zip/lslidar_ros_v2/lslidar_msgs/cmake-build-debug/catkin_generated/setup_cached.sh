#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs:$ROS_PACKAGE_PATH"